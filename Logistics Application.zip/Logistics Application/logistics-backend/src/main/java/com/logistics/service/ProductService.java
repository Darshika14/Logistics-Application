package com.logistics.service;

public class ProductService {
}
