package com.logistics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogitrackBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogitrackBackendApplication.class, args);
    }
}