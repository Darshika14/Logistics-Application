package com.logistics.service;

public class VehicleService {
}
