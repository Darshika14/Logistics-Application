package com.logistics.service;

public class DeliveryAgentService {
}
