package com.logistics.service;

public class ShipmentService {
}
