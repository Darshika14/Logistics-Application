package com.logistics.service;

public class OrderService {
}
