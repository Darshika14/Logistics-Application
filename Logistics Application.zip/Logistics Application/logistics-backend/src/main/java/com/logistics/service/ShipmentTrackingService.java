package com.logistics.service;

public class ShipmentTrackingService {
}
