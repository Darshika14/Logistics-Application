package com.logistics.service;

public class ShipmentAssignmentService {
}
