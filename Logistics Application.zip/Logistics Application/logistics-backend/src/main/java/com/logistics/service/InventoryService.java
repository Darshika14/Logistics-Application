package com.logistics.service;

public class InventoryService {
}
