package com.logistics.service;

public class WarehouseService {
}
