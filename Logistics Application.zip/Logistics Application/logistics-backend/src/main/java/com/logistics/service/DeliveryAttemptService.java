package com.logistics.service;

public class DeliveryAttemptService {
}
